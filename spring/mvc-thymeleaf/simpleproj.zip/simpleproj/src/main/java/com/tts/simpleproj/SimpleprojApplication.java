package com.tts.simpleproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleprojApplication.class, args);
	}

}
